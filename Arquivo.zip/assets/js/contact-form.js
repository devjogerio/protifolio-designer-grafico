// Declara uma função para limpar mensagens de erro existentes nos campos do formulário
function clearContactFormErrors() {
  // Obtém as referências aos elementos de mensagem de erro por id
  var nameError = document.getElementById("name-error");
  var emailError = document.getElementById("email-error");
  var projectTypeError = document.getElementById("project-type-error");
  var messageError = document.getElementById("message-error");
  // Limpa o texto interno de cada elemento de erro, se existir
  if (nameError) nameError.textContent = "";
  if (emailError) emailError.textContent = "";
  if (projectTypeError) projectTypeError.textContent = "";
  if (messageError) messageError.textContent = "";
}

// Declara uma função responsável por exibir mensagens de erro específicas por campo
function showContactFormErrors(errors) {
  // Exibe mensagem de erro para o campo nome, se houver
  if (errors.name) {
    var nameError = document.getElementById("name-error");
    if (nameError) nameError.textContent = errors.name;
  }
  // Exibe mensagem de erro para o campo email, se houver
  if (errors.email) {
    var emailError = document.getElementById("email-error");
    if (emailError) emailError.textContent = errors.email;
  }
  // Exibe mensagem de erro para o campo tipo de projeto, se houver
  if (errors.projectType) {
    var projectTypeError = document.getElementById("project-type-error");
    if (projectTypeError) projectTypeError.textContent = errors.projectType;
  }
  // Exibe mensagem de erro para o campo mensagem, se houver
  if (errors.message) {
    var messageError = document.getElementById("message-error");
    if (messageError) messageError.textContent = errors.message;
  }
}

// Declara uma função que configura o comportamento do formulário de contato
function setupContactForm() {
  // Obtém a referência ao formulário de contato pelo id
  var formElement = document.getElementById("contact-form");
  // Se o formulário não for encontrado, encerra antecipadamente
  if (!formElement) {
    return;
  }
  // Obtém a referência ao elemento de feedback geral do formulário
  var feedbackElement = document.getElementById("contact-feedback");
  // Adiciona ouvinte de evento para o envio do formulário
  formElement.addEventListener("submit", function (event) {
    // Impede o envio padrão para permitir validação customizada
    event.preventDefault();
    // Garante que event.target possui uma referência ao formulário
    var form = event.target;
    // Limpa mensagens de erro anteriores antes de validar novamente
    clearContactFormErrors();
    // Se existir um elemento de feedback, limpa seu conteúdo
    if (feedbackElement) {
      feedbackElement.textContent = "";
    }
    // Lê o valor do campo de nome do formulário
    var nameValue = form.elements.name.value;
    // Lê o valor do campo de email do formulário
    var emailValue = form.elements.email.value;
    // Lê o valor do campo de tipo de projeto
    var projectTypeValue = form.elements.projectType.value;
    // Lê o valor do campo de mensagem
    var messageValue = form.elements.message.value;
    // Monta um objeto com os dados coletados do formulário
    var formData = {
      name: nameValue,
      email: emailValue,
      projectType: projectTypeValue,
      message: messageValue,
    };
    // Executa a função de validação de formulário sobre os dados coletados
    var validationResult = validateContactForm(formData);
    // Se o formulário não for válido, exibe erros específicos e interrompe fluxo
    if (!validationResult.isValid) {
      // Exibe mensagens de erro para os campos relevantes
      showContactFormErrors(validationResult.errors);
      // Caso exista um elemento de feedback geral, informa que há erros
      if (feedbackElement) {
        feedbackElement.textContent =
          "Por favor, corrija os campos destacados antes de enviar.";
      }
      // Encerra a função sem prosseguir para o envio
      return;
    }
    // Se chegou aqui, significa que os dados passaram na validação
    if (feedbackElement) {
      // Define uma mensagem de sucesso amigável para o usuário
      feedbackElement.textContent =
        "Mensagem enviada com sucesso. Em breve entrarei em contato.";
    }
    // Limpa os campos do formulário após envio bem-sucedido
    form.reset();
  });
}

