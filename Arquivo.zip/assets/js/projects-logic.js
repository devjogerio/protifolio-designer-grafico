// Declara uma função responsável por filtrar projetos com base em uma categoria
function filterProjectsByCategory(projects, category) {
  // Verifica se o parâmetro projects é um array válido
  if (!Array.isArray(projects)) {
    // Lança um erro caso a entrada não seja adequada
    throw new Error("A lista de projetos deve ser um array.");
  }
  // Se a categoria for "all", retorna uma cópia rasa de todos os projetos
  if (category === "all") {
    // Usa o operador spread para evitar mutação da lista original
    return [...projects];
  }
  // Normaliza a categoria recebida para string minúscula
  var normalizedCategory = String(category).toLowerCase();
  // Aplica o filtro retornando apenas projetos cuja categoria coincida
  var filteredProjects = projects.filter(function (project) {
    // Garante que a categoria do projeto é tratada como string minúscula
    var projectCategory = String(project.category).toLowerCase();
    // Retorna verdadeiro quando a categoria do projeto corresponde à categoria desejada
    return projectCategory === normalizedCategory;
  });
  // Retorna o array filtrado para o chamador
  return filteredProjects;
}

// Verifica se o ambiente suporta module.exports (Node.js) para exportar a função
if (typeof module !== "undefined" && module.exports) {
  // Exporta a função filterProjectsByCategory para uso em testes unitários em Node.js
  module.exports = {
    filterProjectsByCategory: filterProjectsByCategory,
  };
}

