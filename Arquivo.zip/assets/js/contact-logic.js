// Declara uma função que valida os dados de um formulário de contato
function validateContactForm(formData) {
  // Cria um objeto inicialmente considerado válido
  var result = {
    isValid: true,
    errors: {},
  };
  // Extrai o nome do objeto de dados ou usa string vazia como fallback
  var name = (formData && formData.name) || "";
  // Extrai o email do objeto de dados ou usa string vazia como fallback
  var email = (formData && formData.email) || "";
  // Extrai o tipo de projeto ou usa string vazia como fallback
  var projectType = (formData && formData.projectType) || "";
  // Extrai a mensagem ou usa string vazia como fallback
  var message = (formData && formData.message) || "";
  // Remove espaços extras do nome para validação correta
  var trimmedName = String(name).trim();
  // Remove espaços extras do email para validação correta
  var trimmedEmail = String(email).trim();
  // Remove espaços extras do tipo de projeto
  var trimmedProjectType = String(projectType).trim();
  // Remove espaços extras da mensagem
  var trimmedMessage = String(message).trim();
  // Verifica se o nome está vazio após o trim
  if (trimmedName.length === 0) {
    // Marca o resultado como inválido e registra uma mensagem de erro para o nome
    result.isValid = false;
    result.errors.name = "Informe seu nome completo.";
  }
  // Verifica se o email está vazio
  if (trimmedEmail.length === 0) {
    // Marca o resultado como inválido e registra mensagem de erro
    result.isValid = false;
    result.errors.email = "Informe um e-mail para contato.";
  } else {
    // Define uma expressão regular simples para validar o formato básico de e-mail
    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    // Testa se o email não corresponde ao padrão definido
    if (!emailPattern.test(trimmedEmail)) {
      // Atualiza o estado para inválido e adiciona mensagem de erro específica
      result.isValid = false;
      result.errors.email = "Informe um e-mail válido.";
    }
  }
  // Verifica se o tipo de projeto foi selecionado
  if (trimmedProjectType.length === 0) {
    // Marca o resultado como inválido e define mensagem de erro
    result.isValid = false;
    result.errors.projectType = "Selecione um tipo de projeto.";
  }
  // Verifica se a mensagem foi preenchida com um mínimo de caracteres
  if (trimmedMessage.length < 10) {
    // Configura o estado como inválido e adiciona mensagem de erro para a mensagem
    result.isValid = false;
    result.errors.message = "Descreva brevemente o projeto (mínimo de 10 caracteres).";
  }
  // Retorna o objeto de resultado contendo validade geral e mensagens de erro
  return result;
}

// Verifica se o ambiente suporta module.exports (Node.js) para exportar a função
if (typeof module !== "undefined" && module.exports) {
  // Exporta a função validateContactForm para uso em testes unitários em Node.js
  module.exports = {
    validateContactForm: validateContactForm,
  };
}

