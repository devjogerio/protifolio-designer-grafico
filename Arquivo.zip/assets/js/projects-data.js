// Define um array global contendo os dados dos projetos do portfólio
var projectsData = [
  // Primeiro projeto de branding com identidade visual completa
  {
    id: "branding-identidade-cafeteria",
    title: "Identidade visual para cafeteria artesanal",
    category: "branding",
    year: 2024,
    thumbnail: "./assets/img/projeto-cafeteria.jpg",
    shortDescription:
      "Desenvolvimento de naming, logotipo e sistema visual para uma cafeteria de cafés especiais.",
  },
  // Segundo projeto editorial com foco em diagramação
  {
    id: "editorial-revista-musica",
    title: "Revista independente de música",
    category: "editorial",
    year: 2023,
    thumbnail: "./assets/img/projeto-revista-musica.jpg",
    shortDescription:
      "Projeto gráfico e diagramação para revista impressa com foco em entrevistas e resenhas.",
  },
  // Terceiro projeto digital voltado para redes sociais
  {
    id: "social-campanha-marca-moda",
    title: "Campanha de marca de moda nas redes sociais",
    category: "social",
    year: 2024,
    thumbnail: "./assets/img/projeto-social-moda.jpg",
    shortDescription:
      "Criação de peças para campanha de lançamento de coleção em redes sociais.",
  },
  // Quarto projeto digital voltado para interface simples
  {
    id: "digital-landingpage-evento",
    title: "Landing page para evento criativo",
    category: "digital",
    year: 2022,
    thumbnail: "./assets/img/projeto-landingpage-evento.jpg",
    shortDescription:
      "Layout de landing page para divulgação de evento de design e criatividade.",
  },
  // Quinto projeto de ilustração autoral
  {
    id: "illustration-poster-filme",
    title: "Poster ilustrado para festival de cinema",
    category: "illustration",
    year: 2023,
    thumbnail: "./assets/img/projeto-poster-filme.jpg",
    shortDescription:
      "Ilustração autoral para cartaz de festival de cinema independente.",
  },
  // Sexto projeto editorial digital
  {
    id: "editorial-relatorio-anual",
    title: "Relatório anual interativo",
    category: "editorial",
    year: 2024,
    thumbnail: "./assets/img/projeto-relatorio-anual.jpg",
    shortDescription:
      "Design de relatório anual digital com foco em legibilidade e hierarquia visual.",
  },
];

