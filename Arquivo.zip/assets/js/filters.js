// Declara uma função responsável por criar o HTML de um cartão de projeto
function createProjectCardElement(project) {
  // Cria o elemento article que servirá como cartão base
  var card = document.createElement("article");
  // Adiciona a classe CSS correspondente ao cartão de projeto
  card.className = "project-card";
  // Cria o elemento de imagem para exibir o thumbnail do projeto
  var image = document.createElement("img");
  // Define a URL da imagem com base na propriedade thumbnail do projeto
  image.src = project.thumbnail;
  // Define o texto alternativo descrevendo a imagem do projeto
  image.alt = project.title;
  // Adiciona a classe CSS de imagem do projeto
  image.className = "project-image";
  // Cria o elemento div para envolver o conteúdo textual do cartão
  var body = document.createElement("div");
  // Define a classe CSS para o corpo do cartão
  body.className = "project-body";
  // Cria o elemento de título do projeto
  var title = document.createElement("h3");
  // Define o texto do título com base no campo title do projeto
  title.textContent = project.title;
  // Define a classe CSS para o título do projeto
  title.className = "project-title";
  // Cria o elemento de parágrafo para exibir a categoria do projeto
  var category = document.createElement("p");
  // Define o texto da categoria em formato legível
  category.textContent = "Categoria: " + project.category;
  // Define a classe CSS para a categoria do projeto
  category.className = "project-category";
  // Cria o elemento de parágrafo para a descrição curta do projeto
  var description = document.createElement("p");
  // Define o texto da descrição com base no campo shortDescription do projeto
  description.textContent = project.shortDescription;
  // Define a classe CSS para a descrição do projeto
  description.className = "project-description";
  // Adiciona o título, categoria e descrição ao corpo do cartão
  body.appendChild(title);
  body.appendChild(category);
  body.appendChild(description);
  // Adiciona a imagem e o corpo ao cartão principal
  card.appendChild(image);
  card.appendChild(body);
  // Retorna o elemento de cartão completamente construído
  return card;
}

// Declara uma função que atualiza a grade de projetos com base em uma lista fornecida
function renderProjectsGrid(projects) {
  // Obtém a referência ao elemento da grade de projetos na página
  var gridElement = document.getElementById("projects-grid");
  // Se o elemento não existir, encerra a função mais cedo para evitar erros
  if (!gridElement) {
    return;
  }
  // Marca a grade como ocupada para tecnologias assistivas
  gridElement.setAttribute("aria-busy", "true");
  // Remove qualquer conteúdo anterior da grade
  gridElement.innerHTML = "";
  // Percorre a lista de projetos recebida como parâmetro
  projects.forEach(function (project) {
    // Cria um cartão de projeto individual para o item atual
    var cardElement = createProjectCardElement(project);
    // Adiciona o cartão criado à grade de projetos
    gridElement.appendChild(cardElement);
  });
  // Indica que o carregamento da grade foi concluído
  gridElement.setAttribute("aria-busy", "false");
}

// Declara uma função para configurar o comportamento dos botões de filtro
function setupProjectFilters() {
  // Obtém todos os botões de filtro presentes na página
  var filterButtons = document.querySelectorAll(".filter-button");
  // Se não houver botões de filtro, não há nada a configurar
  if (!filterButtons || filterButtons.length === 0) {
    return;
  }
  // Função interna responsável por atualizar o estado visual do botão ativo
  function updateActiveFilterButton(activeButton) {
    // Percorre todos os botões de filtro para remover o estado ativo
    filterButtons.forEach(function (button) {
      // Remove a classe de botão ativo de cada botão
      button.classList.remove("filter-button-active");
    });
    // Adiciona a classe de ativo ao botão atualmente selecionado
    activeButton.classList.add("filter-button-active");
  }
  // Percorre cada botão de filtro para configurar os ouvintes de eventos
  filterButtons.forEach(function (button) {
    // Adiciona o evento de clique a cada botão de filtro
    button.addEventListener("click", function () {
      // Obtém o valor da categoria a partir do atributo data-category
      var category = button.getAttribute("data-category");
      // Aplica a filtragem aos dados globais de projetos
      var filteredProjects = filterProjectsByCategory(projectsData, category);
      // Atualiza a grade exibindo apenas os projetos filtrados
      renderProjectsGrid(filteredProjects);
      // Atualiza visualmente qual botão está ativo
      updateActiveFilterButton(button);
    });
  });
  // Realiza uma renderização inicial exibindo todos os projetos na grade
  renderProjectsGrid(filterProjectsByCategory(projectsData, "all"));
}

