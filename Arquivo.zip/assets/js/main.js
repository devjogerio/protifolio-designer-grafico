// Declara uma função que configura o comportamento do menu móvel
function setupMobileMenuToggle() {
  // Obtém a referência ao botão de alternância do menu
  var toggleButton = document.querySelector(".menu-toggle");
  // Obtém a referência ao elemento de navegação principal
  var navElement = document.getElementById("site-navigation");
  // Se qualquer um dos elementos não existir, não há menu para configurar
  if (!toggleButton || !navElement) {
    return;
  }
  // Adiciona um ouvinte de evento de clique ao botão de menu
  toggleButton.addEventListener("click", function () {
    // Verifica se o menu está atualmente aberto consultando a classe nav-open
    var isOpen = navElement.classList.contains("nav-open");
    // Se estiver aberto, remove a classe; caso contrário, adiciona
    if (isOpen) {
      navElement.classList.remove("nav-open");
      // Atualiza o atributo aria-expanded para refletir o estado fechado
      toggleButton.setAttribute("aria-expanded", "false");
    } else {
      navElement.classList.add("nav-open");
      // Atualiza o atributo aria-expanded para refletir o estado aberto
      toggleButton.setAttribute("aria-expanded", "true");
    }
  });
}

// Declara uma função que configura a rolagem suave para links de navegação internos
function setupSmoothScrollNavigation() {
  // Seleciona todos os links de navegação que apontam para âncoras internas
  var navLinks = document.querySelectorAll("a.nav-link[href^='#']");
  // Se não houver links de navegação, encerra a função cedo
  if (!navLinks || navLinks.length === 0) {
    return;
  }
  // Adiciona ouvinte de clique a cada link de navegação encontrado
  navLinks.forEach(function (link) {
    // Configura o comportamento de clique individual
    link.addEventListener("click", function (event) {
      // Impede o comportamento padrão de pular imediatamente para a âncora
      event.preventDefault();
      // Obtém o valor do atributo href do link clicado
      var targetId = link.getAttribute("href");
      // Se o href não começar com # ou for vazio, não faz nada
      if (!targetId || targetId.charAt(0) !== "#") {
        return;
      }
      // Busca o elemento de destino correspondente ao id informado
      var targetElement = document.querySelector(targetId);
      // Se o elemento alvo não for encontrado, encerra sem erro
      if (!targetElement) {
        return;
      }
      // Usa a API scrollIntoView para rolagem suave até o elemento alvo
      targetElement.scrollIntoView({ behavior: "smooth", block: "start" });
      // Após a navegação, fecha o menu móvel se ele estiver aberto
      var navElement = document.getElementById("site-navigation");
      var toggleButton = document.querySelector(".menu-toggle");
      if (navElement && toggleButton && navElement.classList.contains("nav-open")) {
        navElement.classList.remove("nav-open");
        toggleButton.setAttribute("aria-expanded", "false");
      }
    });
  });
}

// Declara uma função para atualizar dinamicamente o ano do rodapé
function setupFooterYear() {
  // Busca o elemento que deve receber o ano atual no rodapé
  var yearElement = document.getElementById("footer-year");
  // Se o elemento não existir, não há nada para configurar
  if (!yearElement) {
    return;
  }
  // Obtém o ano atual utilizando o objeto Date do JavaScript
  var currentYear = new Date().getFullYear();
  // Define o conteúdo de texto do elemento com o ano atual
  yearElement.textContent = String(currentYear);
}

// Declara uma função principal para inicializar os comportamentos da página
function initPortfolioSite() {
  // Configura o menu móvel e sua alternância de estado
  setupMobileMenuToggle();
  // Configura a rolagem suave da navegação interna
  setupSmoothScrollNavigation();
  // Configura a grade de projetos e filtros correspondentes
  setupProjectFilters();
  // Configura o comportamento do formulário de contato
  setupContactForm();
  // Atualiza o ano do rodapé dinamicamente
  setupFooterYear();
}

// Aguarda o carregamento do DOM antes de inicializar as funcionalidades do site
document.addEventListener("DOMContentLoaded", function () {
  // Invoca a função principal de inicialização do portfólio
  initPortfolioSite();
});

