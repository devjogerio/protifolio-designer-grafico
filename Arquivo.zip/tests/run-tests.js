// Importa a função de testes para a lógica de projetos
var projectsTests = require("./projects-logic.test.js");
// Importa a função de testes para a lógica de formulário de contato
var contactTests = require("./contact-logic.test.js");

// Executa os testes relacionados à lógica de filtragem de projetos
projectsTests.runProjectsLogicTests();
// Executa os testes relacionados à validação do formulário de contato
contactTests.runContactLogicTests();
// Exibe uma mensagem no console indicando que todos os testes foram executados sem erros de asserção
console.log("Todos os testes de lógica foram executados com sucesso.");

