// Importa o módulo de asserção nativo do Node.js
var assert = require("assert");
// Importa a função de filtragem de projetos a partir do módulo de lógica
var projectLogicModule = require("../assets/js/projects-logic.js");
// Extrai a função filterProjectsByCategory do módulo importado
var filterProjectsByCategory = projectLogicModule.filterProjectsByCategory;

// Declara uma função que executa testes relacionados à filtragem de projetos
function runProjectsLogicTests() {
  // Define uma lista de projetos de exemplo para uso nos testes
  var sampleProjects = [
    { id: "1", category: "branding" },
    { id: "2", category: "editorial" },
    { id: "3", category: "branding" },
  ];
  // Executa teste verificando se a categoria "all" retorna todos os itens
  var allProjects = filterProjectsByCategory(sampleProjects, "all");
  // Assegura que o número de projetos retornados corresponde ao total original
  assert.strictEqual(allProjects.length, 3, "Deve retornar todos os projetos ao usar 'all'.");
  // Executa filtragem para a categoria branding
  var brandingProjects = filterProjectsByCategory(sampleProjects, "branding");
  // Garante que a quantidade de projetos filtrados para branding é igual a 2
  assert.strictEqual(
    brandingProjects.length,
    2,
    "Deve retornar apenas projetos com categoria 'branding'."
  );
  // Verifica se todas as categorias retornadas são realmente branding
  brandingProjects.forEach(function (project) {
    // Usa assert para garantir que a categoria seja exatamente 'branding'
    assert.strictEqual(project.category, "branding", "Categoria inesperada em resultado filtrado.");
  });
}

// Exporta a função de teste para ser chamada a partir de outro arquivo
module.exports = {
  runProjectsLogicTests: runProjectsLogicTests,
};

