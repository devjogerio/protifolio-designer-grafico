// Importa o módulo de asserção nativo do Node.js
var assert = require("assert");
// Importa o módulo de lógica de validação de formulário de contato
var contactLogicModule = require("../assets/js/contact-logic.js");
// Extrai a função validateContactForm do módulo importado
var validateContactForm = contactLogicModule.validateContactForm;

// Declara uma função que executa testes para a validação do formulário de contato
function runContactLogicTests() {
  // Cria um conjunto de dados considerados válidos para teste positivo
  var validFormData = {
    name: "Nome Exemplo",
    email: "email@exemplo.com",
    projectType: "branding",
    message: "Mensagem com mais de dez caracteres.",
  };
  // Executa a validação com os dados válidos
  var validResult = validateContactForm(validFormData);
  // Garante que o resultado seja marcado como válido
  assert.strictEqual(validResult.isValid, true, "Formulário válido deve ser aceito.");
  // Cria um conjunto de dados claramente inválidos para teste negativo
  var invalidFormData = {
    name: "",
    email: "email-invalido",
    projectType: "",
    message: "curta",
  };
  // Executa a validação com os dados inválidos
  var invalidResult = validateContactForm(invalidFormData);
  // Verifica se o resultado geral é marcado como inválido
  assert.strictEqual(invalidResult.isValid, false, "Formulário inválido deve ser rejeitado.");
  // Garante que existam mensagens de erro para todos os campos obrigatórios
  assert.ok(invalidResult.errors.name, "Deve haver erro para o campo nome.");
  assert.ok(invalidResult.errors.email, "Deve haver erro para o campo email.");
  assert.ok(invalidResult.errors.projectType, "Deve haver erro para o tipo de projeto.");
  assert.ok(invalidResult.errors.message, "Deve haver erro para a mensagem.");
}

// Exporta a função de testes para ser utilizada em um runner externo
module.exports = {
  runContactLogicTests: runContactLogicTests,
};

