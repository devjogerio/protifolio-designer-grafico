# Portfólio de Designer Gráfico

Portfólio profissional estático para designers gráficos, desenvolvido com **HTML5**, **CSS3** e **JavaScript puro**, pensado para ser publicado em **GitHub Pages** com foco em performance, acessibilidade e SEO básico.

Este repositório acompanha o PRD formal em:

- [PRD-portfolio-designer-grafico.md](./PRD-portfolio-designer-grafico.md)

## 1. Estrutura do projeto

```text
/
├─ index.html              # Página principal (home, sobre, projetos, contato)
├─ PRD-portfolio-designer-grafico.md
├─ README.md
├─ GUIA-DE-ESTILO.md
├─ assets/
│  ├─ css/
│  │  └─ styles.css        # Estilos globais e responsividade
│  ├─ js/
│  │  ├─ projects-data.js  # Lista de projetos (dados mockados)
│  │  ├─ projects-logic.js # Lógica pura de filtro de projetos
│  │  ├─ contact-logic.js  # Lógica pura de validação do formulário de contato
│  │  ├─ filters.js        # Renderização de cards e filtros da galeria
│  │  ├─ contact-form.js   # Integração da validação com o formulário na página
│  │  └─ main.js           # Inicialização de menu, scroll suave e footer
│  └─ img/                 # Imagens do portfólio e social preview (a adicionar)
└─ tests/
   ├─ projects-logic.test.js
   ├─ contact-logic.test.js
   └─ run-tests.js         # Runner simples de testes via Node
```

## 2. Requisitos

- Node.js instalado (para rodar os testes de lógica).
- Navegador moderno (Chrome, Firefox, Edge, Safari) para uso e inspeção do site.
- Não há variáveis de ambiente obrigatórias neste momento.
  - Se futuramente for integrado um serviço de envio de e-mail (ex.: EmailJS, API própria), as credenciais **devem** ser definidas em `.env` (não versionado) e documentadas em `.env.example` **sem valores reais**.

## 3. Como executar localmente

1. Clonar o repositório:

```bash
git clone <URL_DO_REPOSITORIO>
cd portifolio-designer-grafico
```

2. Abrir o arquivo `index.html` diretamente no navegador **ou** servir via HTTP simples, por exemplo:

```bash
python3 -m http.server 8000
```

E acessar em `http://localhost:8000`.

> Observação: usar um servidor HTTP ajuda a simular de forma mais próxima o comportamento em produção (GitHub Pages).

## 4. Testes

Os testes cobrem a lógica de filtro de projetos e a validação do formulário de contato.

Para executar todos os testes:

```bash
node tests/run-tests.js
```

Se tudo estiver correto, você verá a mensagem:

```text
Todos os testes de lógica foram executados com sucesso.
```

### 4.1 Escopo dos testes atuais

- `projects-logic.test.js`

  - Garante que `filterProjectsByCategory` retorna todos os projetos quando a categoria é `all`.
  - Garante que o filtro por uma categoria específica (ex.: `branding`) retorna apenas projetos daquela categoria.

- `contact-logic.test.js`
  - Valida que um conjunto de dados completo e coerente é aceito.
  - Valida que dados ausentes ou inválidos geram mensagens de erro para todos os campos obrigatórios.

## 5. Deploy em GitHub Pages

1. Criar o repositório no GitHub e enviar o código:

```bash
git init
git remote add origin git@github.com:<USUARIO>/<REPO>.git
git add .
git commit -m "feat: primeira versão do portfólio"
git push -u origin main
```

2. No GitHub, acessar **Settings → Pages**:

- **Source**: branch `main` (ou `master`).
- **Directory**: `/` (root).

3. Aguardar a publicação na URL padrão:

- `https://<USUARIO>.github.io/<REPO>/`

4. Ativar HTTPS:

- Em _Settings → Pages_, marcar **“Enforce HTTPS”** assim que o certificado estiver disponível.

### 5.1 Domínio customizado (opcional)

1. Registrar um domínio próprio (ex.: `seunome.com`).
2. Configurar um registro CNAME no painel de DNS apontando para `seuusuario.github.io`.
3. Adicionar um arquivo `CNAME` na raiz do repositório contendo apenas o domínio customizado.
4. Aguardar a propagação do DNS e a emissão do certificado pelo GitHub.

## 6. Performance, acessibilidade e SEO

- Layout **mobile-first**, com breakpoints em 768px e 1024px para ajustar grid de projetos e layout das seções.
- Componentes interativos (links, botões, campos de formulário) possuem foco visível com cor de destaque.
- Formulário de contato com mensagens de erro por campo e feedback geral usando `aria-live`.
- SEO básico implementado em `index.html`:
  - `<title>`, `<meta name="description">`, Open Graph, Twitter Card.
  - JSON-LD `Person` para o designer.

Recomenda-se rodar o **Lighthouse** (via DevTools do navegador) após o deploy no GitHub Pages e iterar até atingir um score ≥ 90 em Performance, Acessibilidade, Boas práticas e SEO, sempre que possível.

## 7. Manutenção futura

- **Adicionar novos projetos**:

  - Incluir novos objetos no array `projectsData` em `assets/js/projects-data.js`.
  - Criar as imagens correspondentes em `assets/img/`.
  - Usar categorias já existentes ou definir novas (lembrando de atualizar os botões de filtro na seção de projetos).

- **Ajustar identidade visual**:

  - Atualizar cores, tipografia e componentes conforme descrito em [GUIA-DE-ESTILO.md](./GUIA-DE-ESTILO.md).

- **Integração com serviços externos** (ex.: envio real de e-mails):
  - Manter segredos fora do repositório (somente em `.env` ou em configurações seguras).
  - Atualizar `.env.example` sempre que novas variáveis forem introduzidas.
