# Guia de Estilo – Portfólio de Designer Gráfico

Este guia resume as decisões visuais e de UI adotadas na primeira versão do portfólio. Ele serve como referência para futuras evoluções de layout, componentes e identidade visual.

## 1. Cores

Paleta base definida em `:root` no arquivo `assets/css/styles.css`:

- **Fundo principal**: `--color-background: #0f172a;`
- **Fundo de superfície/cartões**: `--color-surface: #020617;`
- **Texto principal**: `--color-text: #e5e7eb;`
- **Texto secundário/mutado**: `--color-text-muted: #9ca3af;`
- **Destaque principal (botões, ênfases)**: `--color-primary: #f97316;`
- **Foco/acessibilidade**: `--color-focus: #38bdf8;`
- **Bordas suaves**: `--color-border: #1f2937;`
- **Erros (formulário)**: `--color-error: #f97373;`

Princípios:

- Fundo escuro com texto claro para destacar o conteúdo visual (projetos e mockups).
- Cor primária quente (`--color-primary`) para chamar atenção a CTAs principais.
- Cor de foco (`--color-focus`) suficientemente contrastante para navegação por teclado.

## 2. Tipografia

- **Fonte base**: `system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif`.
- **Tamanho base**: ~16px (definido pelo navegador, usado como referência).

Hierarquia sugerida:

- **Títulos de seção (`.section-title`)**
  - Mobile: ~1.5rem
  - Desktop: mantidos próximos para evitar exagero visual.

- **Título principal do hero (`.hero-title`)**
  - Mobile: ~2rem
  - ≥768px: ~2.5rem
  - ≥1024px: ~3rem

- **Texto de corpo**
  - Fonte padrão do `body` com `line-height: 1.6` para boa leitura.

- **Elementos de apoio**
  - `.project-category`, `.footer-copy`, labels de formulário usam tamanhos menores (~0.8–0.9rem).

## 3. Layout e grid

### 3.1 Container

- Largura máxima: `--max-width: 1120px`.
- Padding horizontal: `1.5rem` em todas as telas.

### 3.2 Seções

- Espaçamento vertical padrão: `--section-spacing: 5rem`.
- Seções principais:
  - Hero (`#inicio`)
  - Sobre (`#sobre`)
  - Projetos (`#projetos`)
  - Contato (`#contato`)

### 3.3 Grids

- **Sobre (`.about-grid`)**
  - Mobile: 1 coluna (stack vertical).
  - ≥768px: 2 colunas (texto + habilidades).

- **Projetos (`.projects-grid`)**
  - Mobile: 1 coluna.
  - ≥768px: 2 colunas.
  - ≥1024px: 3 colunas.

- **Contato (`.contact-grid`)**
  - Mobile: 1 coluna (texto + formulário empilhados).
  - ≥768px: 2 colunas (texto à esquerda, formulário à direita).

## 4. Componentes

### 4.1 Botões

- Classe base: `.button`
  - Layout: `inline-flex`, borda arredondada (pill), peso médio.
  - Comportamento: transição em `background-color`, `color`, `transform`, `box-shadow`.

- Variante principal: `.primary-button`
  - Fundo: `--color-primary`.
  - Texto: `#0b1120` (escuro, para contraste).
  - Sombra: destaque suave para sensação de profundidade.

### 4.2 Filtros de projetos

- Classe: `.filter-button`
  - Formato de chip: borda arredondada, fundo transparente.
  - Texto em `--color-text-muted`.

- Estado ativo: `.filter-button-active`
  - Fundo e borda: `--color-primary`.
  - Texto: `#0b1120`.

### 4.3 Cards de projeto

- Contêiner: `.project-card`
  - Fundo: `--color-surface`.
  - Borda: `--color-border`.
  - `border-radius: --radius-md`.

- Imagem: `.project-image`
  - `width: 100%`, `height: 200px`, `object-fit: cover`.

- Texto:
  - `.project-title`: título curto e direto.
  - `.project-category`: texto pequeno, uppercase, com espaçamento entre letras.
  - `.project-description`: texto de apoio em `--color-text-muted`.

### 4.4 Formulário de contato

- Campos (`input`, `select`, `textarea`)
  - Fundo: `#020617`.
  - Borda: `--color-border`.
  - `border-radius: 0.5rem`.

- Erros (`.field-error`)
  - Cor: `--color-error`.

- Feedback geral (`.form-feedback`)
  - Texto neutro, usado para mensagens de sucesso ou aviso.

## 5. Acessibilidade

- Foco visível definido para:
  - Botões (`.button:focus-visible`).
  - Links de navegação (`.nav-link:focus-visible`).
  - Campos de formulário (`input`, `select`, `textarea` com `:focus-visible`).

- Uso de atributos ARIA:
  - `aria-label`, `aria-expanded`, `aria-controls` no botão de menu móvel.
  - `aria-live="polite"` em feedbacks do formulário e na grade de projetos.
  - `role="status"` em `#contact-feedback`.

## 6. Evolução do estilo

Ao atualizar a identidade visual, recomenda-se:

1. Ajustar apenas as variáveis em `:root` sempre que possível (cores, raios, espaçamentos).
2. Manter a hierarquia tipográfica consistente (títulos, corpo, detalhes).
3. Garantir contraste adequado ao alterar cores (ferramentas de contrast checker ajudam a validar WCAG).

Este guia pode ser expandido com exemplos visuais, grids mais detalhados ou variações de componentes conforme o portfólio evoluir.

